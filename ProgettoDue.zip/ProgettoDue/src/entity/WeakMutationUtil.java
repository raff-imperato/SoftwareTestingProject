package entity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class WeakMutationUtil {
    public static void main(String[] args) {
        try {
            String percorsoScript = "/mnt/c/Users/raffa/Desktop/testing/ProgettoDue/src/evosuite.sh";

            ProcessBuilder processBuilder = new ProcessBuilder("wsl", "-e", percorsoScript);
            Process process = processBuilder.start();

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }

            BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            String errorLine;
            while ((errorLine = errorReader.readLine()) != null) {
                System.err.println(errorLine);
            }

            int exitCode = process.waitFor();
            System.out.println("\nEsito del comando: " + exitCode);

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

    }
}
