package entity;

public class InstructionCoverageUtil {
}
