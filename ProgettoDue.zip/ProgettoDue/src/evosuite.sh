#!/bin/bash

# Percorso di EvoSuite
EVOSUITE_PATH="/mnt/c/Users/raffa/Desktop/testing/ProgettoDue/evosuite-1.0.6.jar"

# Nome della classe da testare
CLASS_NAME="XMLParser"

# Percorso del progetto
PROJECT_PATH="/mnt/c/Users/raffa/Desktop/testing/ProgettoDue/ClassesUnderTest/XMLParser/src/ClassUnderTest"

# Percorso delle classi di test
TEST_CLASSES_PATH="/mnt/c/Users/raffa/Desktop/testing/ProgettoDue/ClassesUnderTest/XMLParser/test/student/albertoPetilloUno"

# Esegui EvoSuite
java -jar $EVOSUITE_PATH -measureCoverage -class $CLASS_NAME -Djunit=$CLASS_NAME -projectCP $PROJECT_PATH:$TEST_CLASSES_PATH
