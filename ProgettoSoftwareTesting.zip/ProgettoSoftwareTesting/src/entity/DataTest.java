package entity;

public class DataTest {
    enum Producer {
        STUDENT,
        EVOSUITE,
        RANDOOP
    }
    private String name;
    private float instructionCoverage;
    private float weakMutation;
    private String classUT;
    private Producer author;
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public float getInstructionCoverage() {
        return instructionCoverage;
    }
    public void setInstructionCoverage(float instructionCoverage) {
        this.instructionCoverage = instructionCoverage;
    }
    public float getWeakMutation() {
        return weakMutation;
    }
    public void setWeakMutation(float weakMutation) {
        this.weakMutation = weakMutation;
    }
    public String getClassUT() {
        return classUT;
    }
    public void setClassUT(String classUT) {
        this.classUT = classUT;
    }
    public Producer getAuthor() {
        return author;
    }
    public void setAuthor(Producer author) {
        this.author = author;
    }
    public DataTest(String name, float instructionCoverage, float weakMutation, String classUT, Producer author) {
        this.name = name;
        this.instructionCoverage = instructionCoverage;
        this.weakMutation = weakMutation;
        this.classUT = classUT;
        this.author = author;
    }
}
