#!/bin/bash

# Percorso di EvoSuite
EVOSUITE_PATH="/home/raff/IdeaProjects/ProgettoSoftwareTesting/evosuite-1.0.6.jar"

# Nome della classe da testare
CLASS_NAME="XMLParser"

# Percorso del progetto
PROJECT_PATH="/home/raff/Desktop/ClassesUnderTest/XMLParser/bin/ClassUnderTest"

# Percorso delle classi di test
TEST_CLASSES_PATH="/home/raff/Desktop/ClassesUnderTest/XMLParser/bin/student/albertoPetilloUno"

# Verifica del path
echo "Classpath: $PROJECT_PATH:$TEST_CLASSES_PATH"

# Esegui EvoSuite
java -jar $EVOSUITE_PATH -measureCoverage -class $CLASS_NAME -Djunit=$CLASS_NAME -projectCP $PROJECT_PATH:$TEST_CLASSES_PATH -Dcriterion=WEAKMUTATION
