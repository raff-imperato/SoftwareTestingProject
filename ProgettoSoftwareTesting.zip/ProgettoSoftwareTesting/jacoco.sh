#!/bin/bash

# Definisci il percorso del tuo file .jar e il nome del tuo progetto
JAR_PATH="/home/raff/Desktop/XMLParser_Petillo/XMLParser_Petillo.jar"
PROJECT_NAME="XMLParser_Petillo"

# Definisci il percorso al tuo runner di test JUnit e alla tua classe di test
JUNIT_PATH="/usr/share/java/junit-platform-console-standalone.jar"
TEST_CLASS="student.albertoPetilloUno.StudentTest"
CLASS_PATH="/home/raff/Desktop/XMLParser_Petillo/"

# Esegui i tuoi test con l'agente jacoco
java -javaagent:/home/raff/IdeaProjects/ProgettoSoftwareTesting/jacocoagent.jar=destfile=jacoco.exec -jar $JUNIT_PATH --class-path $CLASS_PATH --scan-class-path --include-classname $TEST_CLASS

# Crea un report in formato html
java -jar /home/raff/IdeaProjects/ProgettoSoftwareTesting/jacococli.jar report jacoco.exec --classfiles $CLASS_PATH --html /home/raff/IdeaProjects/ProgettoSoftwareTesting/
