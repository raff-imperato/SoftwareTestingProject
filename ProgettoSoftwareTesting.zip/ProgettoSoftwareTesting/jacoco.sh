#!/bin/bash

# Definisci il percorso del tuo file .jar e il nome del tuo progetto
JAR_PATH="/home/raff/Desktop/XMLParser_Petillo/XMLParser_Petillo.jar"
PROJECT_NAME="XMLParser_Petillo"

# Esegui il tuo programma con l'agente jacoco
java -javaagent:/home/raff/IdeaProjects/ProgettoSoftwareTesting/jacocoagent.jar=destfile=jacoco.exec -jar $JAR_PATH

# Crea un report in formato xml
java -jar /home/raff/IdeaProjects/ProgettoSoftwareTesting/jacococli.jar report jacoco.exec --classfiles /home/raff/Desktop/XMLParser_Petillo/fileClass/ --sourcefiles /home/raff/Desktop/XMLParser_Petillo/fileSource/ --xml jacoco.xml

# Stampa le metriche di copertura
#echo "Coverage metrics for $PROJECT_NAME:"
#grep -oP 'counter type="LINE" missed="\K\d+"' jacoco.xml
#grep -oP 'counter type="LINE" covered="\K\d+"' jacoco.xml
